import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Moon, Sun, BookOpen, Globe2, Landmark, Compass, Mail, Share2, Bookmark, BookmarkCheck, Clock, ChevronRight, ChevronLeft, Map, Info, Grip, Flame, Layers, User } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import Fuse from "fuse.js";

// =============================================
// ArchaeologyWala — single-file React site
// TailwindCSS for styling. Uses framer-motion, lucide-react, react-markdown, fuse.js.
// =============================================

// ---------- Sample Content ----------
const samplePosts = [
  {
    slug: "pottery-through-ages",
    title: "Pottery Through the Ages: From Neolithic to Classical",
    author: "Pryank Wadhera",
    date: "2025-08-21",
    hero: "https://images.unsplash.com/photo-1545239351-1141bd82e8a6?q=80&w=1400&auto=format&fit=crop",
    tags: ["material culture", "ceramics", "field methods"],
    minutes: 9,
    body: `# Pottery Through the Ages

Pottery is one of the most **diagnostic** classes of artifacts in archaeology.

## Neolithic beginnings
Handmade, low-fired vessels appear with the rise of sedentism.

## Form & function
Rim profiles, tempers, and surface treatments are key for *typological* studies.

## Classical refinements
Wheel-thrown finewares, slips, and painted motifs enable tight **chronologies**.

> Field note: Sherds dominate most survey assemblages; bring sturdy bags!

### Further reading
- Rice, *Pottery Analysis*
- Orton & Hughes, *Pottery in Archaeology*
`,
  },
  {
    slug: "archaeology-101-field-kit",
    title: "Archaeology 101: Building a Field Kit",
    author: "Pryank Wadhera",
    date: "2025-07-10",
    hero: "https://images.unsplash.com/photo-1519120944692-1f7e6e7fbd3d?q=80&w=1400&auto=format&fit=crop",
    tags: ["field methods", "how-to", "gear"],
    minutes: 6,
    body: `# Archaeology 101: Building a Field Kit

A dependable kit keeps digs safe and efficient.

## Essentials
- Trowel (pointed and margin)
- Brushes (soft + stiff)
- Scale bars & photo board
- Hand lens (10x)

## Recording
- Waterproof notebook
- Context sheets
- GPS/total station access

### Safety
Sun protection, hydration plan, first aid.
`,
  },
  {
    slug: "digital-archaeology",
    title: "Digital Archaeology: Drones, Photogrammetry, and 3D",
    author: "Pryank Wadhera",
    date: "2025-06-14",
    hero: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1400&auto=format&fit=crop",
    tags: ["technology", "survey", "3D"],
    minutes: 8,
    body: `# Digital Archaeology: Drones, Photogrammetry, and 3D

Cheap sensors + fast compute have transformed documentation.

## Flight planning
Overlap, GSD, and ground control points matter.

## From pixels to points
Structure-from-Motion generates dense point clouds and textured meshes.

## Ethics
Mind permissions, privacy, and site protection.
`,
  },
];

// Utility
const slugify = (str: string) =>
  str.toLowerCase().replace(/[^a-z0-9\\s-]/g, "").trim().replace(/\\s+/g, "-");

const formatDate = (iso: string) =>
  new Date(iso + "T00:00:00Z").toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });

const estimateMinutes = (md: string) => Math.max(3, Math.round(md.split(/\\s+/).length / 220));

const loadLS = (key: string, fallback: any) => {
  try { const val = localStorage.getItem(key); return val ? JSON.parse(val) : fallback; } catch { return fallback; }
};
const saveLS = (key: string, val: any) => { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} };

// UI primitives
const Chip: React.FC<{children: React.ReactNode, active?: boolean, onClick?: () => void}> = ({ children, active, onClick }) => (
  <button onClick={onClick} className={`px-3 py-1 rounded-full border text-sm transition shadow-sm hover:shadow ${active ? 'bg-black text-white dark:bg-white dark:text-black' : 'bg-white/70 dark:bg-zinc-800/70 backdrop-blur border-zinc-200 dark:border-zinc-700'}`}>{children}</button>
);
const Card: React.FC<{children: React.ReactNode, onClick?: () => void, className?: string}> = ({ children, onClick, className }) => (
  <div onClick={onClick} className={`rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white/70 dark:bg-zinc-900/70 backdrop-blur shadow-sm hover:shadow-md transition ${className || ''}`}>{children}</div>
);
const Button: React.FC<{children: React.ReactNode, onClick?: () => void, variant?: 'solid'|'ghost', className?: string, title?: string}> = ({ children, onClick, variant='solid', className, title }) => (
  <button title={title} onClick={onClick} className={`inline-flex items-center gap-2 px-4 py-2 rounded-2xl text-sm font-medium transition ${variant==='solid' ? 'bg-black text-white dark:bg-white dark:text-black hover:opacity-90' : 'bg-transparent hover:bg-zinc-100 dark:hover:bg-zinc-800'} ${className||''}`}>{children}</button>
);

// App
export default function App() {
  const [dark, setDark] = useState<boolean>(() => loadLS('aw:dark', true));
  const [page, setPage] = useState<'home'|'blog'|'article'|'learn'|'library'|'contribute'|'about'>("home");
  const [query, setQuery] = useState("");
  const [posts, setPosts] = useState(()=>loadLS('aw:posts', samplePosts));
  const [bookmarks, setBookmarks] = useState<string[]>(() => loadLS('aw:bookmarks', []));
  const [fontScale, setFontScale] = useState<number>(() => loadLS('aw:fontScale', 100));
  const [activePost, setActivePost] = useState<typeof samplePosts[number] | null>(null);
  const [likes, setLikes] = useState<Record<string, number>>(() => loadLS('aw:likes', {}));
  const [newsletterOK, setNewsletterOK] = useState(false);
  const [submissions, setSubmissions] = useState<any[]>(()=> loadLS('aw:submissions', []));

  useEffect(() => { document.documentElement.classList.toggle('dark', dark); saveLS('aw:dark', dark); }, [dark]);
  useEffect(() => { saveLS('aw:bookmarks', bookmarks); }, [bookmarks]);
  useEffect(() => { saveLS('aw:fontScale', fontScale); }, [fontScale]);
  useEffect(() => { saveLS('aw:likes', likes); }, [likes]);
  useEffect(() => { saveLS('aw:posts', posts); }, [posts]);
  useEffect(() => { saveLS('aw:submissions', submissions); }, [submissions]);

  const fuse = useMemo(() => new Fuse(posts, { keys: ['title', 'tags', 'body'], threshold: 0.33 }), [posts]);
  const filtered = useMemo(() => !query ? posts : fuse.search(query).map(r => r.item), [query, fuse, posts]);

  const openPost = (p: typeof samplePosts[number]) => { setActivePost(p); setPage('article'); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const toggleBookmark = (slug: string) => setBookmarks(bm => bm.includes(slug) ? bm.filter(s => s!==slug) : [...bm, slug]);
  const clap = (slug: string) => setLikes(prev => ({ ...prev, [slug]: (prev[slug]||0) + 1 }));

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white dark:from-zinc-950 dark:to-zinc-900 text-zinc-900 dark:text-zinc-100" style={{ fontSize: `${fontScale}%` }}>
      <Header dark={dark} setDark={setDark} setPage={setPage} query={query} setQuery={setQuery} />
      <main id="content" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatePresence mode="wait">
          {page === 'home' && (
            <motion.section key="home" initial={{opacity:0, y:12}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-12}} className="py-10 sm:py-16">
              <Hero setPage={setPage} />
              <Features />
              <PhotoStory />
              <LearningTracks tracks={learningTracks} />
              <LatestPosts posts={posts} openPost={openPost} bookmarks={bookmarks} toggleBookmark={toggleBookmark} />
            </motion.section>
          )}

          {page === 'blog' && (
            <motion.section key="blog" initial={{opacity:0, y:12}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-12}} className="py-10 sm:py-16">
              <BlogIndex posts={filtered} openPost={openPost} bookmarks={bookmarks} toggleBookmark={toggleBookmark} query={query} setQuery={setQuery} />
            </motion.section>
          )}

          {page === 'article' && activePost && (
            <motion.section key="article" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="py-6">
              <ArticleView post={activePost} onBack={() => setPage('blog')} glossary={{}} bookmarked={bookmarks.includes(activePost.slug)} toggleBookmark={() => toggleBookmark(activePost.slug)} clap={() => clap(activePost.slug)} likes={likes[activePost.slug]||0} />
            </motion.section>
          )}

          {page === 'learn' && (
            <motion.section key="learn" initial={{opacity:0, y:12}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-12}} className="py-10 sm:py-16">
              <LearningTracks tracks={learningTracks} full />
            </motion.section>
          )}

          {page === 'library' && (
            <motion.section key="library" initial={{opacity:0, y:12}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-12}} className="py-10 sm:py-16">
              <ResourceLibrary />
            </motion.section>
          )}

          {page === 'contribute' && (
            <motion.section key="contribute" initial={{opacity:0, y:12}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-12}} className="py-10 sm:py-16">
              <Contribute submissions={submissions} setSubmissions={setSubmissions} setPage={setPage} addPost={(p:any)=>setPosts((prev:any)=>[p,...prev])} />
            </motion.section>
          )}

          {page === 'about' && (
            <motion.section key="about" initial={{opacity:0, y:12}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-12}} className="py-10 sm:py-16">
              <About newsletterOK={newsletterOK} setNewsletterOK={setNewsletterOK} />
            </motion.section>
          )}
        </AnimatePresence>
      </main>
      <Footer setPage={setPage} fontScale={fontScale} setFontScale={setFontScale} />
      <SEO />
    </div>
  );
}

// Header
const Header: React.FC<{dark: boolean; setDark: (b:boolean)=>void; setPage: (p:any)=>void; query:string; setQuery:(s:string)=>void}> = ({ dark, setDark, setPage, query, setQuery }) => (
  <header className="sticky top-0 z-50 border-b border-zinc-200/70 dark:border-zinc-800/70 backdrop-blur bg-white/70 dark:bg-zinc-900/60">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center gap-3">
      <button onClick={()=>setPage('home')} className="flex items-center gap-3 font-semibold text-lg">
        <Landmark className="w-6 h-6" /> ArchaeologyWala <span className="hidden sm:inline text-zinc-500">— a world by Pryank Wadhera</span>
      </button>
      <nav className="hidden md:flex items-center gap-2 ml-4">
        {[
          {k:'home', label:'Explore', icon: <Globe2 className="w-4 h-4"/>},
          {k:'blog', label:'Blog', icon: <BookOpen className="w-4 h-4"/>},
          {k:'learn', label:'Learn', icon: <Layers className="w-4 h-4"/>},
          {k:'contribute', label:'Contribute', icon: <Mail className="w-4 h-4"/>},
          {k:'about', label:'About', icon: <Info className="w-4 h-4"/>},
        ].map(item => (
          <Button key={item.k} variant="ghost" onClick={()=>setPage(item.k as any)}><span className="opacity-70">{item.icon}</span>{item.label}</Button>
        ))}
      </nav>
      <div className="ml-auto flex items-center gap-2 w-full md:w-auto">
        <div className="flex items-center gap-2 px-3 py-2 rounded-2xl border border-zinc-200 dark:border-zinc-700 bg-white/80 dark:bg-zinc-800/80 w-full md:w-80">
          <Search className="w-4 h-4 opacity-60"/>
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search archaeology, tags, posts…" className="bg-transparent outline-none w-full"/>
        </div>
        <Button variant="ghost" onClick={()=>setDark(!dark)} title="Toggle dark mode">{dark? <Sun className="w-5 h-5"/> : <Moon className="w-5 h-5"/>}</Button>
      </div>
    </div>
    <a href="#content" className="sr-only focus:not-sr-only">Skip to content</a>
  </header>
);

// Sections referenced below (shortened to keep the template light)
const Features: React.FC = () => (
  <section className="mt-12">
    <h2 className="text-2xl font-semibold mb-4">Best-in-class features</h2>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {[
        {icon: <Search className="w-5 h-5"/>, title:"Instant search", desc:"Fuzzy search across posts, tags, and notes."},
        {icon: <Clock className="w-5 h-5"/>, title:"Reading progress", desc:"Sticky progress bar and time estimates."},
        {icon: <Bookmark className="w-5 h-5"/>, title:"Bookmarks", desc:"Save articles to read later (offline-ready)."},
        {icon: <Share2 className="w-5 h-5"/>, title:"Share & cite", desc:"Copy link, quick BibTeX and JSON‑LD metadata."},
        {icon: <Grip className="w-5 h-5"/>, title:"TOC & anchors", desc:"Wikipedia-style deep linking to sections."},
        {icon: <Flame className="w-5 h-5"/>, title:"Photo stories", desc:"Immersive image galleries and captions."},
      ].map((f,i)=> (
        <Card key={i} className="p-5">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-amber-100 text-amber-900 dark:bg-amber-900/30 dark:text-amber-300">{f.icon}</div>
            <div>
              <div className="font-medium">{f.title}</div>
              <div className="text-sm text-zinc-600 dark:text-zinc-400">{f.desc}</div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  </section>
);

const PhotoStory: React.FC = () => {
  const [idx, setIdx] = useState(0);
  const items = [
    {src:"https://images.unsplash.com/photo-1509718443690-d8e2fb3474b7?q=80&w=1400&auto=format&fit=crop", caption:"Desert caravan route — tracing trade networks."},
    {src:"https://images.unsplash.com/photo-1523419409543-8c1ae1c1f729?q=80&w=1400&auto=format&fit=crop", caption:"Temple capitals — classical orders and symbolism."},
    {src:"https://images.unsplash.com/photo-1519682337058-a94d519337bc?q=80&w=1400&auto=format&fit=crop", caption:"Field documentation — context is everything."},
  ];
  return (
    <section className="mt-12">
      <h3 className="text-xl font-semibold mb-3">Photo story</h3>
      <Card className="overflow-hidden">
        <div className="relative">
          <img src={items[idx].src} alt="story" className="w-full h-[360px] object-cover" loading="lazy"/>
          <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/60 to-transparent text-white">{items[idx].caption}</div>
          <div className="absolute inset-0 flex items-center justify-between p-3">
            <Button variant="ghost" onClick={()=>setIdx((idx-1+items.length)%items.length)}><ChevronLeft/></Button>
            <Button variant="ghost" onClick={()=>setIdx((idx+1)%items.length)}><ChevronRight/></Button>
          </div>
        </div>
      </Card>
    </section>
  );
};

const Hero: React.FC<{setPage:(p:any)=>void}> = ({ setPage }) => (
  <section className="grid lg:grid-cols-2 gap-8 items-center">
    <div className="space-y-6">
      <h1 className="text-4xl sm:text-5xl font-bold tracking-tight">ArchaeologyWala <span className="opacity-60">— a world by</span> <span className="underline decoration-amber-400">Pryank Wadhera</span></h1>
      <p className="text-lg text-zinc-600 dark:text-zinc-300 max-w-prose">Everything about archaeology: field methods, materials, digital tools, timelines, and stories from the past.</p>
      <div className="flex flex-wrap gap-3">
        <Button onClick={()=>setPage('blog')}><BookOpen className="w-4 h-4"/> Read the Blog</Button>
        <Button variant="ghost" onClick={()=>setPage('learn')}><Layers className="w-4 h-4"/> Start Learning</Button>
        <Button variant="ghost" onClick={()=>setPage('library')}><Compass className="w-4 h-4"/> Explore Library</Button>
      </div>
    </div>
    <div className="relative">
      <img src="https://images.unsplash.com/photo-1541417904950-b855846fe074?q=80&w=1600&auto=format&fit=crop" alt="Archaeological site" className="rounded-3xl shadow-md w-full h-[360px] object-cover" loading="lazy"/>
      <div className="absolute bottom-4 left-4 bg-black/60 text-white px-4 py-2 rounded-2xl text-sm backdrop-blur">Photo story • Sahara rock art</div>
    </div>
  </section>
);

// LearningTracks (short) + ResourceLibrary (short) + BlogIndex (short) + ArticleView (short) + Contribute (short) + About + Footer + SEO
// For brevity in this template, we only stub these; your canvas has the full versions. You can copy them over later.

const LearningTracks: React.FC<{tracks:any[]; full?:boolean}> = ({ tracks }) => (
  <section className="mt-12">
    <h3 className="text-xl font-semibold mb-3">Learning paths</h3>
    <Card className="p-5">Curated tracks (stub).</Card>
  </section>
);

const ResourceLibrary: React.FC = () => (
  <section className="mt-12">
    <h3 className="text-xl font-semibold mb-3">Resource Library</h3>
    <Card className="p-5">Datasets, tools & videos (stub).</Card>
  </section>
);

const BlogIndex: React.FC<{posts:any[]; openPost:(p:any)=>void; bookmarks:string[]; toggleBookmark:(s:string)=>void; query:string; setQuery:(s:string)=>void}> = ({ posts, openPost }) => (
  <section className="mt-12">
    <h3 className="text-xl font-semibold mb-3">Blog</h3>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {posts.map(p => (
        <Card key={p.slug} className="p-4">
          <div className="text-xs text-zinc-500">{formatDate(p.date)} • {p.minutes || estimateMinutes(p.body)} min read</div>
          <button onClick={()=>openPost(p)} className="text-lg font-semibold text-left hover:underline decoration-amber-400 underline-offset-2">{p.title}</button>
        </Card>
      ))}
    </div>
  </section>
);

const ArticleView: React.FC<{post:any; onBack:()=>void; glossary:Record<string,string>; bookmarked:boolean; toggleBookmark:()=>void; clap:()=>void; likes:number}> = ({ post, onBack, clap, likes }) => (
  <section className="mt-6">
    <div className="flex items-center justify-between gap-2">
      <Button variant="ghost" onClick={onBack}><ChevronLeft className="w-4 h-4"/> Back</Button>
      <Button onClick={()=>clap(post.slug)} title="Applaud">👏 <span className="text-xs opacity-70">{likes}</span></Button>
    </div>
    <Card className="overflow-hidden mt-3">
      <img src={post.hero} alt="cover" className="w-full h-64 object-cover"/>
      <div className="p-6">
        <div className="text-sm text-zinc-500">{formatDate(post.date)} • {post.minutes || estimateMinutes(post.body)} min read • <span className="inline-flex items-center gap-1"><User className="w-3.5 h-3.5"/>{post.author}</span></div>
        <h1 className="text-3xl font-bold mt-1">{post.title}</h1>
        <div className="prose prose-zinc dark:prose-invert max-w-none mt-4">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>{post.body}</ReactMarkdown>
        </div>
      </div>
    </Card>
  </section>
);

const Contribute: React.FC<{submissions:any[]; setSubmissions:(fn:any)=>void; setPage:(p:any)=>void; addPost:(p:any)=>void}> = () => (
  <section className="mt-12">
    <h3 className="text-xl font-semibold mb-3">Contribute</h3>
    <Card className="p-5">Submission form (stub). Use your canvas version for the full experience.</Card>
  </section>
);

const About: React.FC<{newsletterOK:boolean; setNewsletterOK:(b:boolean)=>void}> = () => (
  <section className="mt-12">
    <h3 className="text-xl font-semibold mb-3">About</h3>
    <Card className="p-5">ArchaeologyWala — a world by Pryank Wadhera.</Card>
  </section>
);

const Footer: React.FC<{setPage:(p:any)=>void; fontScale:number; setFontScale:(n:number)=>void}> = ({ setPage, fontScale, setFontScale }) => (
  <footer className="border-t border-zinc-200 dark:border-zinc-800 mt-12 py-6 text-sm">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
      <div>© {new Date().getFullYear()} ArchaeologyWala</div>
      <div className="flex items-center gap-2">
        <Button variant="ghost" onClick={()=>setPage('contribute')}>Contribute</Button>
        <div className="flex items-center gap-2">
          A↕
          <input type="range" min={80} max={120} value={fontScale} onChange={(e)=>setFontScale(parseInt(e.target.value))}/>
        </div>
      </div>
    </div>
  </footer>
);

const SEO: React.FC = () => {
  const jsonld = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "ArchaeologyWala",
    url: typeof window !== 'undefined' ? window.location.origin : 'https://archaeologywala.example',
    sameAs: [],
    creator: { "@type": "Person", name: "Pryank Wadhera" },
    potentialAction: {
      "@type": "SearchAction",
      target: `${typeof window !== 'undefined' ? window.location.origin : 'https://archaeologywala.example'}/?q={search_term_string}`,
      "query-input": "required name=search_term_string"
    }
  } as const;
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonld) }} />;
};

const learningTracks = [
  { id: "foundations", title: "Foundations of Archaeology", milestones: [] },
  { id: "materials", title: "Materials & Analysis", milestones: [] },
];