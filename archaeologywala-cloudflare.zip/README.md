# ArchaeologyWala — Vite + React (Cloudflare Pages)

This repo contains a ready-to-deploy version of **ArchaeologyWala**.

## Local dev
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
# output: dist/
```

## Deploy to Cloudflare Pages
1. Push this folder to a new GitHub repo (public or private).
2. In the Cloudflare dashboard → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.
3. Pick your repo, then set:
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
4. Save and deploy. Your site will appear at `<project>.pages.dev`.

To add a custom domain: Pages project → **Custom domains** → **Set up a domain**, then follow the prompts.

> Docs: Build configuration, Git integrations, Vite guide.